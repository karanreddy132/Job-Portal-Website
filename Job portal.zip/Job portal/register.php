<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Registration</title>


    <style>
        form {
            width: 60%;
            margin-left: 20%;
            padding: 40px;
            background-color: rgb(135, 206, 235, 0.8);
            margin-top: 7em;
            box-shadow: 10px 10px 8px 10px rgb(0, 0, 0, 0.5);
            border-radius: 10px;
            margin-bottom: 50px;
        }

        button {
            margin-left: 45%;
        }

        body {
            background-image: url('career.jpg');
            background-size: cover;
        }

        .container {
            animation: transitionIn 0.75s;
        }

        @keyframes transitionIn {

            from {
                opacity: 0;
                transform: rotateX(-10deg);
            }

            to {
                opacity: 1;
                transform: rotateX(0);
            }
        }

        .ipassword {
            position: absolute;
            top: 67%;
            left: 71%;
            cursor: pointer;
        }

        .icpassword {
            position: absolute;
            top: 79%;
            left: 71%;
            cursor: pointer;
        }

        @media screen and (max-width: 700px) {
            .container {
                width: 650px;
                margin-left: -50px;
            }

            button {
                margin-left: 35%;
            }

            .ipassword {
                top: 60%;
                left: 80%;
            }

            .icpassword {
                position: absolute;
                top: 70.5%;
                left: 80%;
            }

        }
    </style>
</head>

<body>
    <div class="container">
        <form action="config.php" method="post">
            <div class="mb-3">
                <label for="exampleInputName1" class="form-label" required>Username</label>
                <input type="text" class="form-control" id="exampleInputName1" name="name">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" required>
                <div id="emailHelp" class="form-text" style="color: white;">We'll never share your email with anyone else.</div>
            </div>
            <div class="mb-3">
                <label for="exampleInputNumber1" class="form-label">Mobile number</label>
                <input type="number" class="form-control" id="exampleInputNumber1" name="Mobile_no" required>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" name="pass" required>
                <span><i class="fa fa-eye ipassword" aria-hidden="true" id="ipassword" onclick="myFunction1()"></i></span>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword2" class="form-label">Confirm Password</label>
                <input type="password" class="form-control" id="exampleInputPassword2" name="cpass" required>
                <span><i class="fa fa-eye icpassword" aria-hidden="true" id="icpassword" onclick="myFunction2()"></i></span>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Submit</button>

            <p>Already registered?<a href="login.php">login</a></p>
        </form>
        <script>
            var x = false;

            function myFunction1() {
                if (x) {
                    document.getElementById("exampleInputPassword1").setAttribute("type", "password");
                    document.getElementById("ipassword").style.color = "black";
                    x = false;
                } else {
                    document.getElementById("exampleInputPassword1").setAttribute("type", "text");
                    document.getElementById("ipassword").style.color = "rgb(135, 206, 235, 0.8)";
                    x = true;
                }
            }

            var y = false;

            function myFunction2() {
                if (y) {
                    document.getElementById("exampleInputPassword2").setAttribute("type", "password");
                    document.getElementById("icpassword").style.color = "black";
                    y = false;
                } else {
                    document.getElementById("exampleInputPassword2").setAttribute("type", "text");
                    document.getElementById("icpassword").style.color = "rgb(135, 206, 235, 0.8)";
                    y = true;
                }
            }
        </script>
    </div>
</body>

</html>