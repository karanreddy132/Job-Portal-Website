<?php
include 'config.php'
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Jobs</title>
    <style>
        .table-row {
            margin-left: 200px;
            width: 87%;
        }

        .navigation {
            position: fixed;
            width: 100%;
            top: 0;
        }

        .table-row {
            margin-top: 100px;
        }

        .sidebar a.active {
            background-color: rgb(200, 36, 134);
            color: white;
        }

        .table-row {
            animation: transitionIn 0.75s;
        }

        @keyframes transitionIn {

            from {
                opacity: 0;
                transform: rotateX(-10deg);
            }

            to {
                opacity: 1;
                transform: rotateX(0);
            }
        }

        @media screen and (max-width: 700px) {

            .table-row {
                margin-left: 10px;
            }

            .navigation {
                position: fixed;
                width: 100%;
                top: 0;
            }

            .sidebar {
                margin-top: 0;
            }

            .table-row {
                margin-top: 150px;
            }
        }
    </style>
</head>

<body>


    <div class="navigation">
        <nav class="navbar navbar-expand-lg navbar-light bg-dark">
            <div class="container-fluid">
                <a href="index.php" style="text-decoration: none;">
                    <p class="navbar-brand" style="font-size: 30px; color:rgb(221,221,221);">Admin Dashboard</p>
                </a>
            </div>
        </nav>

        <!-- The sidebar -->
        <div class="sidebar">
            <a href="index.php">Jobs</a>
            <a class="active" href="jobs.php">Canditates applied</a>
            <a href="contact.php">Contact</a>
            <a href="about.php">About</a>
        </div>

    </div>

    <div class="table table-row">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Canditate Name</th>
                    <th scope="col">Position</th>
                    <th scope="col">Passout year</th>
                </tr>
            </thead>

            <?php
            $conn = mysqli_connect("localhost", "root", "", "jobs");
            $sql = "SELECT Name,Applyfor,Year FROM `Canditates`;";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                $i = 0;
                while ($rows = $result->fetch_assoc()) {

                    echo "
                        <tbody>
                            <tr>
                                <td>" . ++$i . "</td>
                                <td>" . $rows['Name'] . "</td>
                                <td>" . $rows['Applyfor'] . "</td>
                                <td>" . $rows['Year'] . "</td>
                            </tr>";
                }
            } else {
                echo "";
            }
            ?>
            </tbody>
        </table>
    </div>

</body>

</html>