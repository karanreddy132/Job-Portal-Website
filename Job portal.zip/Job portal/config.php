<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <!--bootstrap JS-->
</head>

<?php

$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'jobs';


$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die('We are not able to connect with the database: ' . mysqli_connect_error());
}

if (isset($_POST['submit'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['Mobile_no'];
    $password = $_POST['pass'];
    $cpassword = $_POST['cpass'];

    $query = "insert into Employees(Username,Email,Mobile_no,Password) values('$name','$email','$mobile','$password')";

    if ($cpassword != $password || strlen($password) < 8) {
        if ($cpassword != $password) {
            echo '<script>alert("Password and confirm password should be same...")</script>';
        } else {
            echo '<script>alert("Password should contain atleast 8 characters...")</script>';
        }
    } else if (mysqli_query($conn, $query)) {
        header('location:formsubmited.php');
    } else {
        echo "Error: File not submitted: " . mysqli_error($conn);
    }
}

session_start();

if (isset($_POST['Login'])) {

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM employees WHERE Username = '$name' AND Password = '$password'";
    $result = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($result);

    if ($count==1) {

        if (!empty($_POST['remember'])) {
            setcookie('name', $name, time() + (365 * 24 * 60 * 60));
            setcookie('password', $password, time() + (365 * 24 * 60 * 60));
        } else {
            if (isset($_COOKIE["name"])) {
                setcookie("name", "");
            }
            if (isset($_COOKIE["password"])) {
                setcookie("password", "");
            }
        }
        header('location:career.php');
    }

    else {
        echo '<script>alert("Invalid username or password!!!")</script>';
        exit();
    }
}

if (isset($_POST['jobpost'])) {

    $Cname = $_POST['Cname'];
    $position = $_POST['position'];
    $jobdesc = $_POST['jobdesc'];
    $skillsreq = $_POST['skillsreq'];
    $ctc = $_POST['CTC'];

    $query = "INSERT INTO `postjob`(`Cname`, `Position`, `Jobdesc`, `Skills_req`, `CTC`) VALUES ('$Cname','$position','$jobdesc','$skillsreq','$ctc')";

    if (mysqli_query($conn, $query)) {
        echo "Job posted successfully. Click <a href = 'career.php'>here</a> to go to dashboard";
    } else {
        echo "ERROR : While posting job : " . mysqli_error($conn);
    }
}

if (isset($_POST['apply'])) {

    $cname = $_POST['cname'];
    $qual = $_POST['qualification'];
    $year = $_POST['passoutyear'];
    $applyfor = $_POST['applyfor'];

    $query = "INSERT INTO `canditates`(`Name`, `Qualification`, `Year`, `Applyfor`) VALUES ('$cname','$qual','$year','$applyfor')";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "Job application submitted successfully!!! click <a href='career.php'>here</a> to go to career page";
    } else {
        echo "ERROR : Job application not submitted : " . mysqli_error($conn);
    }
}

if(isset($_POST['logout'])){
    header('location:login.php');
}

mysqli_close($conn);

?>