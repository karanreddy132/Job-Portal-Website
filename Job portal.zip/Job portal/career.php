<?php
include 'config.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Career</title>

    <style>
        .jumbotron-fluid {
            background-image: url('banner-1.jpg');
            background-size: cover;
            height: 200px;
        }

        .container {
            padding: 70px;
        }

        .second {
            margin-left: 50px;
            margin-top: 50px;
        }

        .jobs {
            padding: 50px;
            margin: 20px;
            box-shadow: 5px 10px #888888;
            height: 340px;
            border-style: solid;
            border-color: black;
        }

        .jobs:hover {
            box-shadow: 10px 15px #888888;
            height: 350px;
            margin-top: 10px;
        }

        .second {
            animation: transitionIn 0.75s;
        }

        .logout {
            text-align: center;
            margin: 20px;
        }

        .logout button {
            padding: 10px;
        }

        @keyframes transitionIn {

            from {
                opacity: 0;
                transform: rotateX(-10deg);
            }

            to {
                opacity: 1;
                transform: rotateX(0);
            }
        }

        @media screen and (max-width: 700px) {

            .jobs {
                margin-left: -10px;
                margin-right: 50px;
            }

            .one {
                margin-left: 5px;
                margin-right: 5px;
                margin-top: 10px;
            }
        }
    </style>

</head>

<body>

    <div class="row one">
        <div class="col-12">
            <div class="jumbotron jumbotron-fluid">
                <div class="container">
                    <h1 class="display-4" style="text-align: center;">Job Portal</h1>
                    <p class="lead" style="text-align: center;">Best jobs available matching your skills</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row second">
        <?php
        $conn = mysqli_connect("localhost", "root", "", "jobs");
        $sql = "SELECT Cname,Position,CTC,Skills_req,Jobdesc FROM `postjob`;";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            while ($rows = $result->fetch_assoc()) {

                echo '<div class = "col-md-4">
                        <div class = "jobs">
                            <h3 style = "text-align: center;">' . $rows['Position'] . '</h3>
                            <h4 style = "text-align: center;">' . $rows['Cname'] . '</h4>
                            <p style = "color: black text-align: justify;">' . $rows['Jobdesc'] . '</p>
                            <p style = "color: black"><b>Skills required : </b>' . $rows['Skills_req'] . '</p>
                            <p style = "color: black"><b>CTC</b>' . $rows['CTC'] . '</p>
                            <button type="submit" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">Apply now</button> 
                        </div>
                    </div>';
            }
        }
        ?>
        <div class="logout">
            <form action="config.php" method="POST">
                <button type="submit" class="btn btn-primary" name="logout">
                    logout
                </button>
            </form>
        </div>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">New message</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="config.php" method="POST">
                            <div class="mb-3">
                                <label for="recipient-name" class="col-form-label">Name</label>
                                <input type="text" class="form-control" id="recipient-name" name="cname" required>
                            </div>
                            <div class="mb-3">
                                <label for="message-text" class="col-form-label">Applying for</label>
                                <input type="text" class="form-control" id="Applying_for" name="applyfor" required>
                            </div>
                            <div class="mb-3">
                                <label for="message-text" class="col-form-label">Qualification</label>
                                <input type="text" class="form-control" id="Qualification" name="qualification" required>
                            </div>
                            <div class="mb-3">
                                <label for="message-text" class="col-form-label">Year of Passout</label>
                                <input type="text" class="form-control" id="Year" name="passoutyear" required>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary" name="apply">Apply</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>