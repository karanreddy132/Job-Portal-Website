<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


    <title>Contact</title>
    <style>
        .container iframe {
            width: 100%;
            margin-left: 100px;
        }

        .contact_content {
            margin-left: 110px;
            margin-top: 10px;
        }

        .Follow {
            margin-left: 110px;
        }

        .Contact {
            margin-left: 110px;
        }

        .Follow a {
            color: rgb(255, 255, 255);
            padding: 5px;
            font-size: 30px;
        }

        .Contact a {
            color: rgb(255, 255, 255);
            padding: 5px;
            font-size: 30px;
        }

        .container-fluid p {
            color: rgb(221, 0, 0);
        }

        .Contact a:hover {
            font-size: 35px;
        }

        .Follow a:hover {
            font-size: 35px;
        }

        .address {
            margin-left: 7%;
            display: grid;
            grid-template-columns: auto auto auto;
            background-color: black;
            padding: 20px;
            width: 100%;
        }

        .address b {
            color: white;
        }

        .address h3 {
            color: white;
        }

        .contact-row {
            width: 50%;
        }

        .location {
            margin-left: 10px;
        }

        .navigation {
            position: fixed;
            width: 100%;
            top: 0;
        }

        .container {
            margin-top: 100px;
        }

        .sidebar a.active {
            background-color: rgb(200, 36, 134);
            color: white;
        }

        .container {
            animation: transitionIn 0.75s;
        }

        @keyframes transitionIn {

            from {
                opacity: 0;
                transform: rotateX(-10deg);
            }

            to {
                opacity: 1;
                transform: rotateX(0);
            }
        }

        @media screen and (max-width: 700px) {

            .container iframe {
                margin-left: 0px;
            }

            .Follow {
                margin-left: 0px;
            }

            .Contact {
                margin-left: 0px;
            }

            .contact_content {
                margin-left: 0px;
            }

            .address {
                display: grid;
                grid-template-columns: auto;
                margin-left: 0;
                padding-left: 0;
            }

            .navigation {
                position: fixed;
                width: 100%;
                top: 0;
            }

            .sidebar {
                margin-top: 0;
            }

            .container {
                margin-top: 150px;
            }
        }
    </style>
</head>

<body>

    <div class="navigation">
        <nav class="navbar navbar-expand-lg navbar-light bg-dark">
            <div class="container-fluid">
                <a href="index.php" style="text-decoration: none;">
                    <p class="navbar-brand" style="font-size: 30px; color:rgb(221,221,221);">Admin Dashboard</p>
                </a>
            </div>
        </nav>

        <!-- The sidebar -->
        <div class="sidebar">
            <a href="index.php">Jobs</a>
            <a href="jobs.php">Canditates applied</a>
            <a class="active" href="contact.php">Contact</a>
            <a href="about.php">About</a>
        </div>
    </div>

    <div class="container">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3803.1691113313627!2d78.1208514147993!3d17.594702687954744!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcbefdc136bffbb%3A0x73414ff6594c9191!2sIndian%20Institute%20Of%20Technology%E2%80%93Hyderabad%20(IIT%E2%80%93Hyderabad)!5e0!3m2!1sen!2sin!4v1644571190294!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

        <div class="address">
            <div class="location contact-row">
                <p><b>Location :<br>
                        Indian Institute of technology Hyderabad <br>
                        Near NH-65, Sangareddy, Kandi, Telangana 502285</b></p>
                <p><b>Call: (+91) 9633124037</b></p>
                <p><b>Mail: support@gmail.com</b></p>
            </div>
            <div class="Follow contact-row">
                <h3 style="padding: 10px;">Follow us</h3>
                <a href="https://www.facebook.com/pages/category/Education-website/1Stopai-102490171820303/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="https://twitter.com/onestopai"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href="https://in.linkedin.com/company/1stop-ai"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                <a href="https://www.instagram.com/1stop.ai/?hl=en"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            </div>
            <div class="Contact contact-row">
                <h3 style="padding: 10px;">Contact us</h3>
                <a href="https://api.Whatsapp.com/send?phone: +919876543210"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                <a href="tel: +919876543210"><i class="fa fa-telegram" aria-hidden="true"></i></a>
                <a href="mailto: support@1stop.ai"><i class="fa fa-envelope-o" aria-hidden="true"></i></a>
            </div>
        </div>
    </div>
</body>

</html>