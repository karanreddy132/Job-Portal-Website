<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>About</title>

    <style>
        .aboutus {
            animation: transitionIn 0.75s;
        }

        @keyframes transitionIn {

            from {
                opacity: 0;
                transform: rotateX(-10deg);
            }

            to {
                opacity: 1;
                transform: rotateX(0);
            }
        }

        .sidebar a.active {
            background-color: rgb(200, 36, 134);
            color: white;
        }

        .about_content h2 {
            text-align: center;
            color: rgb(200, 36, 134);
        }

        .mission_content h2 {
            text-align: center;
            color: rgb(200, 36, 134);
        }

        .aboutus {
            height: 650px;
        }

        .navigation {
            position: fixed;
            width: 100%;
            top: 0;
        }

        .aboutus {
            margin-top: 100px;
        }

        @media screen and (max-width: 700px) {
            .navigation {
                position: fixed;
                width: 100%;
                top: 0;
            }

            .sidebar {
                margin-top: 0;
            }

            .aboutus {
                margin-top: 150px;
            }
        }
    </style>

</head>

<body>

    <div class="navigation">
        <nav class="navbar navbar-expand-lg navbar-light bg-dark">
            <div class="container-fluid">
                <a href="index.php" style="text-decoration: none;">
                    <p class="navbar-brand" style="font-size: 30px; color:rgb(221,221,221);">Admin Dashboard</p>
                </a>
            </div>
        </nav>

        <!-- The sidebar -->
        <div class="sidebar">
            <a href="index.php">Jobs</a>
            <a href="jobs.php">Canditates applied</a>
            <a href="contact.php">Contact</a>
            <a class="active" href="about.php">About</a>
        </div>

    </div>

    <div class="aboutus">
        <div class="content">
            <div class="about_content">
                <h2>ABOUT US</h2>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Minus sed deserunt, nihil ipsum quod sit
                    rerum aspernatur? Doloribus reprehenderit sint accusantium aspernatur ea, necessitatibus, dolorem
                    velit commodi expedita repudiandae voluptates? Praesentium ad ex enim blanditiis obcaecati! Ex Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum autem, delectus incidunt quia ab labore veniam vero culpa rerum exercitationem aliquid ea eius similique, laboriosam temporibus. Laboriosam cupiditate corporis eum! Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, nam saepe quaerat quo vitae ab quos totam quia omnis magni quibusdam fugiat, repellat ipsa alias molestiae itaque id labore consequatur.
                    minima nihil iusto. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Modi, nesciunt
                    voluptas. Consequuntur dicta nobis assumenda fuga id! Eum cupiditate dolores nulla, magnam,
                    provident quis temporibus dolorum debitis, exercitationem dignissimos sequi! Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur ullam quam facilis? Eum itaque eius repellendus ipsam nam debitis delectus aliquam totam magnam, dolorem rerum facere, voluptatem ea numquam esse. Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci cumque odit vel magni distinctio, provident laborum dignissimos aliquid commodi illo repellat facilis iusto dolorem cupiditate. Aperiam ipsam fugit ipsum itaque?</p>
            </div>
            <hr>
            <div class="mission_content">
                <h2>OUR MISSION</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit officia molestiae, a hic at
                    sint rerum iste doloribus? Unde voluptatem officiis voluptas, ullam aspernatur exercitationem saepe
                    voluptatibus quia animi! Quisquam quam vero fuga nisi in. Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit, amet consectetur adipisicing elit. Esse dicta necessitatibus, molestias quod delectus deleniti sed mollitia quasi id consectetur maiores veritatis ipsam odio rerum obcaecati at voluptate! Consectetur, quidem. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem, illo? Blanditiis reprehenderit alias doloribus facere voluptate odit temporibus quasi ipsa obcaecati sit possimus est velit itaque, ex deserunt assumenda eos!
                    adipisicing elit. Nemo provident ad ea in sapiente deserunt illo nulla assumenda dolore illum id, Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos quasi animi facere magnam obcaecati voluptatem distinctio aliquid quis officia unde delectus incidunt iusto expedita maiores tempora, repellat, eos rem eum.
                    quas, dolorem cupiditate, at quasi laborum est ab temporibus. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi rem tenetur qui tempore ipsum maiores mollitia eligendi atque tempora fugit quod magnam, expedita eos ullam inventore sed sit. Placeat, reprehenderit. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ipsum cumque consectetur hic placeat explicabo! Voluptatum non repudiandae ullam voluptatem cum libero repellat deleniti, nostrum dolorum, laboriosam atque fugit iure asperiores.</p>
            </div>
        </div>
    </div>

</body>

</html>