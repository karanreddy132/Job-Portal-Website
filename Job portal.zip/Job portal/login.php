<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Link to add bootstrap code-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!--link to add icons-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Login</title>


    <style>
        form {
            width: 60%;
            margin-left: 20%;
            padding: 40px;
            background-color: rgb(135, 206, 235, 0.8);
            margin-top: 10em;
            box-shadow: 10px 10px 8px 10px rgb(0, 0, 0, 0.5);
            border-radius: 10px;
            margin-bottom: 50px;
        }

        button {
            margin-left: 45%;
        }

        body {
            background-image: url('career.jpg');
            background-size: cover;
        }

        .showPass {
            margin: 5px;
            font-size: 20px;
        }

        .container {
            animation: transitionIn 0.75s;
        }

        @keyframes transitionIn {

            from {
                opacity: 0;
                transform: rotateX(-10deg);
            }

            to {
                opacity: 1;
                transform: rotateX(0);
            }
        }

        span {
            position: absolute;
            cursor: pointer;
            top: 43.5%;
            left: 71%;
        }

        #rememberMe{
            letter-spacing: 5px;
            font-size: 10px;
            cursor: pointer;
        }

        @media screen and (max-width: 700px) {
            .container {
                width: 650px;
                margin-left: -75px;
            }

            button {
                margin-left: 35%;
            }

            span {
                position: absolute;
                cursor: pointer;
                top: 40.5%;
                left: 75%;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <form action="config.php" method="POST">
            <div class="mb-3">
                <label for="exampleInputName1" class="form-label">Username</label>
                <input type="text" class="form-control" id="exampleInputName1" name="name" value="<?php if(isset($_COOKIE['name'])){echo $_COOKIE['name'];}?>" required>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" name="password" value="<?php if(isset($_COOKIE['password'])){echo $_COOKIE['password'];}?>" required>
                <span><i class="fa fa-eye" aria-hidden="true" id="eye" onclick="myFunction()"></i></span>
            </div>
            <div class="mb-3">
                <input type="checkbox" id="rememberMe" name="remember">Remember me
            </div>
            <button type="submit" class="btn btn-primary" name="Login">Submit</button>

            <p>New user?</p>
            <p>Register here <a href="register.php">register</a></p>
        </form>
        <script>
            var x = false;

            function myFunction() {
                if (x) {
                    document.getElementById("exampleInputPassword1").setAttribute("type", "password");
                    document.getElementById("eye").style.color = "black";
                    x = false;
                } else {
                    document.getElementById("exampleInputPassword1").setAttribute("type", "text");
                    document.getElementById("eye").style.color = "rgb(135, 206, 235, 0.8)";
                    x = true;
                }
            }
        </script>
    </div>
</body>

</html>